import React, { useState, useEffect, useRef } from 'react';
import { HiOutlineCube } from 'react-icons/hi';
import StatusBadge from '../components/StatusBadge';
import LoadingSkeleton from '../components/LoadingSkeleton';
import { activeOrders as initialOrders } from '../data/data';
import '../styles/ActiveOrders.css';

function ActiveOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showOtpModal, setShowOtpModal] = useState(false);
  const [selectedOrderId, setSelectedOrderId] = useState(null);
  const [otpValues, setOtpValues] = useState(['', '', '', '']);
  const otpRefs = useRef([]);

useEffect(() => {
  const user = JSON.parse(localStorage.getItem("loggedInUser"));

  fetch(`http://localhost:5000/orders/${user.id}`)
    .then(res => res.json())
    .then(data => {
      setOrders(data.orders);
      setLoading(false);
    });
}, []);

  const updateOrderStatus = (orderId, newStatus) => {
  fetch("http://localhost:5000/update-order-status", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      orderId,
      status: newStatus,
    }),
  }).then(() => {
    setOrders(prev =>
      prev.map(order =>
        order.id === orderId ? { ...order, status: newStatus } : order
      )
    );
  });
};

  const handleAccept = (orderId) => {
    updateOrderStatus(orderId, 'Picked');
  };

  const handleMarkPicked = (orderId) => {
    updateOrderStatus(orderId, 'On the Way');
  };

  const handleMarkDelivered = (orderId) => {
    setSelectedOrderId(orderId);
    setOtpValues(['', '', '', '']);
    setShowOtpModal(true);
  };

  const handleOtpChange = (index, value) => {
    if (value.length > 1) return;
    const newOtp = [...otpValues];
    newOtp[index] = value;
    setOtpValues(newOtp);
    if (value && index < 3) {
      otpRefs.current[index + 1]?.focus();
    }
  };

  const handleOtpKeyDown = (index, e) => {
    if (e.key === 'Backspace' && !otpValues[index] && index > 0) {
      otpRefs.current[index - 1]?.focus();
    }
  };

  const confirmDelivery = () => {
  const otp = otpValues.join("");

  fetch("http://localhost:5000/verify-otp", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      orderId: selectedOrderId,
      otp,
    }),
  })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        updateOrderStatus(selectedOrderId, "Delivered");
        setShowOtpModal(false);
      } else {
        alert("Invalid OTP");
      }
    });
};

  const getActionButtons = (order) => {
    switch (order.status) {
      case 'Pending':
        return (
          <button className="btn btn-primary" onClick={() => handleAccept(order.id)}>
            ✓ Accept Order
          </button>
        );
      case 'Picked':
        return (
          <button className="btn btn-warning" onClick={() => handleMarkPicked(order.id)}>
            🚀 Mark as On the Way
          </button>
        );
      case 'On the Way':
        return (
          <button className="btn btn-success" onClick={() => handleMarkDelivered(order.id)}>
            📦 Mark as Delivered
          </button>
        );
      case 'Delivered':
        return (
          <button className="btn btn-outline" disabled>
            ✅ Delivered
          </button>
        );
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <div>
        <div className="page-header">
          <h1>Active Orders</h1>
          <p>Manage your current deliveries</p>
        </div>
        <LoadingSkeleton type="rows" count={5} />
      </div>
    );
  }

  const pendingCount = orders.filter((o) => o.status === 'Pending').length;

  return (
    <div>
      <div className="page-header">
        <h1>Active Orders</h1>
        <p>Manage your current deliveries</p>
      </div>

      <div className="active-orders-header">
        <div className="active-orders-count">
          Showing <span className="count-num">{orders.length}</span> orders
          {pendingCount > 0 && (
            <> · <span className="count-num">{pendingCount}</span> pending</>
          )}
        </div>
      </div>

      <div className="orders-list">
        {orders.map((order) => (
          <div key={order.id} className="order-card">
            <div className="order-card-top">
              <div className="order-id-section">
                <div className="order-icon">
                  <HiOutlineCube />
                </div>
                <div className="order-id-info">
                  <h4>{order.id}</h4>
                  <p>{order.customer_name} · {order.items} items</p>
                </div>
              </div>
              <StatusBadge status={order.status} />
            </div>

            <div className="order-card-body">
              <div className="order-location">
                <span className="order-location-label">📍 Pickup</span>
                <span className="order-location-value">{order.pickup_location}</span>
              </div>
              <div className="order-location">
                <span className="order-location-label">🏠 Delivery</span>
                <span className="order-location-value">{order.delivery_location}</span>
              </div>
              <div className="order-meta-grid">
                <div className="order-meta-item">
                  <span className="meta-label">Distance:</span>
                  <span className="meta-value">{order.distance}</span>
                </div>
                <div className="order-meta-item">
                  <span className="meta-label">ETA:</span>
                  <span className="meta-value">{order.estimatedTime}</span>
                </div>
                <div className="order-meta-item">
                  <span className="meta-label">Amount:</span>
                  <span className="meta-value">{order.amount}</span>
                </div>
              </div>
            </div>

            <div className="order-card-actions">
              {getActionButtons(order)}
            </div>
          </div>
        ))}
      </div>

      {/* OTP Modal */}
      {showOtpModal && (
        <div className="otp-modal-overlay" onClick={() => setShowOtpModal(false)}>
          <div className="otp-modal" onClick={(e) => e.stopPropagation()}>
            <h3>Verify Delivery OTP</h3>
            <p>Enter the 4-digit OTP provided by the customer</p>
            <div className="otp-inputs">
              {otpValues.map((val, i) => (
                <input
                  key={i}
                  ref={(el) => (otpRefs.current[i] = el)}
                  type="text"
                  maxLength="1"
                  value={val}
                  onChange={(e) => handleOtpChange(i, e.target.value)}
                  onKeyDown={(e) => handleOtpKeyDown(i, e)}
                  autoFocus={i === 0}
                />
              ))}
            </div>
            <div className="otp-modal-actions">
              <button
                className="btn btn-outline"
                onClick={() => setShowOtpModal(false)}
              >
                Cancel
              </button>
              <button
                className="btn btn-success"
                onClick={confirmDelivery}
                disabled={otpValues.join('').length !== 4}
              >
                Confirm Delivery
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default ActiveOrders;
