function ShippingTable() {
  return (
    <div className="card" style={{flex:1}}>
      <h3>Shipping List</h3>

      <table width="100%">
        <thead>
          <tr>
            <th>ID</th>
            <th>Hyderabad</th>
            <th>Weight</th>
            <th>Status</th>
          </tr>
        </thead>

        <tbody>
          <tr>
            <td>#RQ7487</td>
            <td>Gachibowli</td>
            <td>3.4kg</td>
            <td>In Transit</td>
          </tr>

          <tr>
            <td>#RQ7488</td>
            <td>Kukatpally</td>
            <td>2.8kg</td>
            <td>On the Way</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

export default ShippingTable;