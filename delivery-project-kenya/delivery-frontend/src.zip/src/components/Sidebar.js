import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import {
  HiOutlineViewGrid,
  HiOutlineTruck,
  HiOutlineClock,
  HiOutlineCurrencyRupee,
  HiOutlineGift,
  HiOutlineUser,
  HiOutlineLogout,
} from 'react-icons/hi';
import '../styles/Sidebar.css';
import { useNavigate } from "react-router-dom";
const navItems = [
  { path: '/dashboard', icon: HiOutlineViewGrid, label: 'Dashboard' },
  { path: '/active-orders', icon: HiOutlineTruck, label: 'Active Orders', badge: 4 },
  { path: '/order-history', icon: HiOutlineClock, label: 'Order History' },
  { path: '/earnings', icon: HiOutlineCurrencyRupee, label: 'Earnings' },
  { path: '/coupons', icon: HiOutlineGift, label: 'Coupons', badge: 3 },
  { path: '/profile', icon: HiOutlineUser, label: 'Profile' },
];

function Sidebar({ isOpen, onClose }) {
  const navigate = useNavigate();   // ✅ ADD THIS

  const handleLogout = () => {
  localStorage.removeItem("loggedInUser");
  onClose && onClose(); // close sidebar if mobile
  navigate("/login");
};
const [showLogoutPopup, setShowLogoutPopup] = useState(false);
  return (
    <>
      <div
        className={`sidebar-overlay ${isOpen ? 'visible' : ''}`}
        onClick={onClose}
      />
      <aside className={`sidebar ${isOpen ? 'open' : ''}`}>
        <div className="sidebar-header">
          <div className="sidebar-logo">⚡</div>
          <div className="sidebar-brand">
            <h2>Prime-Basket</h2>
            <span>Delivery Partner</span>
          </div>
        </div>

        <nav className="sidebar-nav">
          <div className="nav-section-label">Main Menu</div>
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === '/'}
              className={({ isActive }) =>
                `nav-link ${isActive ? 'active' : ''}`
              }
              onClick={onClose}
            >
              <span className="nav-link-icon">
                <item.icon />
              </span>
              {item.label}
              {item.badge && <span className="nav-badge">{item.badge}</span>}
            </NavLink>
          ))}
        </nav>

        <div className="sidebar-footer">
  <button className="nav-link"  onClick={() => setShowLogoutPopup(true)}>
    <span className="nav-link-icon">
      <HiOutlineLogout />
    </span>
    Logout
  </button>
</div>
      </aside>
      {showLogoutPopup && (
  <div className="logout-popup">
    <div className="logout-box">
      <h3>Confirm Logout</h3>
      <p>Are you sure you want to logout?</p>

      <div className="logout-actions">
        <button
          className="cancel-btn"
          onClick={() => setShowLogoutPopup(false)}
        >
          Cancel
        </button>

        <button
          className="confirm-btn"
          onClick={() => {
            localStorage.removeItem("loggedInUser");
            navigate("/login");
          }}
        >
          Logout
        </button>
      </div>
    </div>
  </div>
)}
    </>
  );
}

export default Sidebar;
