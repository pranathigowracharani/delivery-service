import React, { useState, useEffect } from 'react';
import StatusBadge from '../components/StatusBadge';
import LoadingSkeleton from '../components/LoadingSkeleton';
import { orderHistory as historyData } from '../data/data';
import '../styles/OrderHistory.css';

function OrderHistory() {
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('All');
  const [dateFilter, setDateFilter] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  const filteredOrders = historyData.filter((order) => {
    const matchStatus = statusFilter === 'All' || order.status === statusFilter;
    const matchDate = !dateFilter || order.date === dateFilter;
    return matchStatus && matchDate;
  });

  const deliveredCount = historyData.filter((o) => o.status === 'Delivered').length;
  const cancelledCount = historyData.filter((o) => o.status === 'Cancelled').length;

  if (loading) {
    return (
      <div>
        <div className="page-header">
          <h1>Order History</h1>
          <p>View your past deliveries</p>
        </div>
        <LoadingSkeleton type="grid" count={3} />
        <div style={{ marginTop: 24 }}>
          <LoadingSkeleton type="rows" count={6} />
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="page-header">
        <h1>Order History</h1>
        <p>View your past deliveries</p>
      </div>

      {/* Stats */}
      <div className="history-stats">
        <div className="history-stat-card">
          <h4>{historyData.length}</h4>
          <p>Total Orders</p>
        </div>
        <div className="history-stat-card">
          <h4>{deliveredCount}</h4>
          <p>Delivered</p>
        </div>
        <div className="history-stat-card">
          <h4>{cancelledCount}</h4>
          <p>Cancelled</p>
        </div>
      </div>

      {/* Filters */}
      <div className="history-controls">
        <div className="filter-group">
          <label>Status:</label>
          <select
            className="filter-select"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="All">All Status</option>
            <option value="Delivered">Delivered</option>
            <option value="Cancelled">Cancelled</option>
          </select>
        </div>
        <div className="filter-group">
          <label>Date:</label>
          <input
            type="date"
            className="filter-input"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
          />
        </div>
        {(statusFilter !== 'All' || dateFilter) && (
          <button
            className="btn btn-outline"
            onClick={() => {
              setStatusFilter('All');
              setDateFilter('');
            }}
          >
            Clear Filters
          </button>
        )}
      </div>

      {/* Table */}
      <div className="history-table-wrapper">
        <table className="history-table">
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Customer</th>
              <th>Pickup</th>
              <th>Delivery</th>
              <th>Distance</th>
              <th>Amount</th>
              <th>Status</th>
              <th>Date & Time</th>
            </tr>
          </thead>
          <tbody>
            {filteredOrders.length === 0 ? (
              <tr>
                <td colSpan="8" style={{ textAlign: 'center', padding: '32px', color: 'var(--text-muted)' }}>
                  No orders found matching filters
                </td>
              </tr>
            ) : (
              filteredOrders.map((order) => (
                <tr key={order.id}>
                  <td className="table-order-id">{order.id}</td>
                  <td>{order.customer}</td>
                  <td>{order.pickup}</td>
                  <td>{order.delivery}</td>
                  <td>{order.distance}</td>
                  <td className="table-amount">{order.amount}</td>
                  <td><StatusBadge status={order.status} /></td>
                  <td className="table-date">{order.date}<br />{order.time}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default OrderHistory;
