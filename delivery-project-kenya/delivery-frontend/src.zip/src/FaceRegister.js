import { useRef, useState, useEffect } from "react";
import * as faceapi from "face-api.js";
import "./register.css";
import { useNavigate } from "react-router-dom";

function FaceRegister() {
  const videoRef = useRef();
  const navigate = useNavigate();

  const [image, setImage] = useState("");
  const [modelLoaded, setModelLoaded] = useState(false);
  const [faceDetected, setFaceDetected] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [mobile, setMobile] = useState("");
const [password, setPassword] = useState("");
const [confirmPassword, setConfirmPassword] = useState("");
const [city, setCity] = useState("");
const [aadhaar, setAadhaar] = useState("");
const [pan, setPan] = useState("");
const [dlNumber, setDlNumber] = useState("");
const [dlExpiry, setDlExpiry] = useState("");

const [bankAccount, setBankAccount] = useState("");
const [ifsc, setIfsc] = useState("");
const [accountHolder, setAccountHolder] = useState("");
const [upiId, setUpiId] = useState("");

const [aadhaarFile, setAadhaarFile] = useState(null);
const [panFile, setPanFile] = useState(null);
const [dlFile, setDlFile] = useState(null);
const [message, setMessage] = useState("");
const [errors, setErrors] = useState({});
  // ✅ Load models
  useEffect(() => {
    Promise.all([
      faceapi.nets.tinyFaceDetector.loadFromUri("/models"),
      faceapi.nets.faceLandmark68Net.loadFromUri("/models"),
      faceapi.nets.faceRecognitionNet.loadFromUri("/models"),
    ]).then(() => setModelLoaded(true));
  }, []);

  const startCamera = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true });
    videoRef.current.srcObject = stream;
  };

const detectFace = async () => {
  if (!modelLoaded) {
    setMessage("⚙️ Loading AI...");
    return;
  }

  const result = await faceapi.detectSingleFace(
    videoRef.current,
    new faceapi.TinyFaceDetectorOptions()
  );

  setFaceDetected(!!result);
};
 const capture = () => {
  if (!faceDetected) {
    setMessage("Detect face first");
    return;
  }

  const canvas = document.createElement("canvas");
  canvas.width = videoRef.current.videoWidth;
  canvas.height = videoRef.current.videoHeight;

  canvas.getContext("2d").drawImage(videoRef.current, 0, 0);
  setImage(canvas.toDataURL());
  setMessage("📸 Captured successfully");
};
// ✅ Aadhaar Validation
const validateAadhaar = (value) => {
  const aadhaarRegex = /^[0-9]{12}$/;

  if (!value) return "Aadhaar is required";
  if (!aadhaarRegex.test(value)) return "Invalid Aadhaar (12 digits)";
  
  return "";
};

const validatePan = (value) => {
  const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;

  if (!value) return "PAN is required";
  if (!panRegex.test(value)) return "Invalid PAN format";

  return "";
};

const validateMobile = (v) =>
  /^[0-9]{10}$/.test(v) ? "" : "Invalid mobile number";

const validatePassword = (v) =>
  v.length >= 6 ? "" : "Min 6 characters required";

const validateConfirmPassword = (v) =>
  v === password ? "" : "Passwords do not match";
useEffect(() => {
  setErrors((prev) => ({
    ...prev,
    confirmPassword: validateConfirmPassword(confirmPassword),
  }));
}, [password, confirmPassword]);
const validateDL = (v) =>
  v.length >= 8 ? "" : "Invalid DL number";
const validateAccountHolder = (v) =>
  v.length >= 3 ? "" : "Enter valid name";

const validateDLExpiry = (v) =>
  new Date(v) > new Date() ? "" : "DL expired";

const validateBank = (value) => {
  const accRegex = /^[0-9]{9,18}$/;
  if (!value) return "Bank account required";
  if (!accRegex.test(value)) return "Invalid bank account";
  return "";
};

const validateIFSC = (value) => {
  const ifscRegex = /^[A-Z]{4}0[A-Z0-9]{6}$/;
  if (!value) return "IFSC required";
  if (!ifscRegex.test(value)) return "Invalid IFSC";
  return "";
};

const validateUPI = (value) => {
  const upiRegex = /^[\w.-]+@[\w.-]+$/;
  if (!value) return ""; // optional
  if (!upiRegex.test(value)) return "Invalid UPI ID";
  return "";
};


const handleSubmit = async () => {
  if (!name || !email ||  !mobile || !password || !confirmPassword || !city || !image) {
    setMessage("⚠️ Fill all fields");
    return;
  }

if (password !== confirmPassword) {
  setMessage("❌ Passwords do not match");
  return;
}
const hasErrors = Object.values(errors).some((e) => e);

if (hasErrors) {
  setMessage("❌ Fix errors before submitting");
  return;
}
const validateFile = (file) => {
  if (!file) return "File is required";  // ✅ no error

  const allowed = ["image/jpeg", "image/png", "application/pdf"];
  if (!allowed.includes(file.type)) {
    return "Invalid file type";
  }

  if (file.size > 5 * 1024 * 1024) {
    return "File too large (max 5MB)";
  }

  return null;
};
const aadhaarError = validateFile(aadhaarFile);
const panError = validateFile(panFile);
const dlError = validateFile(dlFile);

const fileError = aadhaarError || panError || dlError;

if (fileError) {
  setMessage("❌ " + fileError);
  return;
}
  try {
    const img = await faceapi.fetchImage(image);

    const result = await faceapi
      .detectSingleFace(img, new faceapi.TinyFaceDetectorOptions())
      .withFaceLandmarks()
      .withFaceDescriptor();

    if (!result) {
      setMessage("❌ Face not detected properly");
      return;
    }

    // ✅ STORE DESCRIPTOR (IMPORTANT)
    const descriptor = Array.from(result.descriptor);

    // const res = await fetch("http://localhost:5000/register", {
    //   method: "POST",
    //   headers: {
    //     "Content-Type": "application/json",
    //   },
    //   body: JSON.stringify({ name, email,  mobile,password,city,descriptor }),
    // });
const formData = new FormData();

// Basic fields
formData.append("name", name);
formData.append("email", email);
formData.append("mobile", mobile);
formData.append("password", password);
formData.append("city", city);

// KYC fields
formData.append("aadhaar", aadhaar);
formData.append("pan", pan);
formData.append("dl_number", dlNumber);
formData.append("dl_expiry", dlExpiry);

// Bank fields
formData.append("bank_account", bankAccount);
formData.append("ifsc", ifsc);
formData.append("account_holder", accountHolder);
formData.append("upi_id", upiId);

// Face descriptor
formData.append("descriptor", JSON.stringify(descriptor));

// Files
if (aadhaarFile) formData.append("aadhaar_doc", aadhaarFile);
if (panFile) formData.append("pan_doc", panFile);
if (dlFile) formData.append("dl_doc", dlFile);

// Send request
const res = await fetch("http://localhost:5000/register", {
  method: "POST",
  body: formData, // ❗ NO headers
});


    const data = await res.json();

    if (data.success) {
      setMessage("✅ Registered");
      setTimeout(() => navigate("/login"), 1500);
    } else {
      setMessage(data.message);
    }
  } catch {
    setMessage("❌ Error");
  }
};

  return (
  <div className="container">
    
      {/* LEFT PANEL */}
      <div className="register-left">
        <span className="tag">PARTNER ONBOARDING</span>

        <h1>
          Register once,<br />
          then use photo-based login verification.
        </h1>

        <p>
          Add your delivery partner details and profile image.
          The same photo will be used for login face matching.
        </p>

        <div className="features">
          <span>Identity photo required</span>
          <span>Shift & vehicle captured</span>
          <span>Dashboard unlocks after face scan</span>
        </div>
      </div>

    {/* RIGHT */}
    <div className="right">
      <h2>Register as Delivery Partner 🚚</h2>

      <input
        type="text"
        placeholder="Full Name"
        onChange={(e) => setName(e.target.value)}
      />

      <input
        type="email"
        placeholder="Email"
        onChange={(e) => setEmail(e.target.value)}
      />
    <input
  type="text"
  placeholder="Mobile Number"
  className={errors.mobile ? "input-error" : ""}
  onChange={(e) => {
    const v = e.target.value;
    setMobile(v);
    setErrors((prev) => ({ ...prev, mobile: validateMobile(v) }));
  }}
/>
{errors.mobile && <p className="error-text">{errors.mobile}</p>}

<input
  type="password"
  placeholder="Password"
  className={errors.password ? "input-error" : ""}
  onChange={(e) => {
    const v = e.target.value;
    setPassword(v);
    setErrors((prev) => ({ ...prev, password: validatePassword(v) }));
  }}
/>
{errors.password && <p className="error-text">{errors.password}</p>}

<input
  type="password"
  placeholder="Confirm Password"
  className={errors.confirmPassword ? "input-error" : ""}
  onChange={(e) => {
    const v = e.target.value;
    setConfirmPassword(v);
    setErrors((prev) => ({
      ...prev,
      confirmPassword: validateConfirmPassword(v),
    }));
  }}
/>
{errors.confirmPassword && (
  <p className="error-text">{errors.confirmPassword}</p>
)}

<input type="text" placeholder="City" onChange={(e) => setCity(e.target.value)} />

<input className={errors.aadhaar ? "input-error" : ""}
  type="text"
  placeholder="Aadhaar Number"
  onChange={(e) => {
    const value = e.target.value;
    setAadhaar(value);

    setErrors((prev) => ({
      ...prev,
      aadhaar: validateAadhaar(value),
    }));
  }}
/>
{errors.aadhaar && (
  <p className="error-text">{errors.aadhaar}</p>
)}
<input type="file" onChange={(e) => setAadhaarFile(e.target.files[0])} />

<input
  type="text"
  placeholder="PAN Card"
  className={errors.pan ? "input-error" : ""}
  onChange={(e) => {
    const value = e.target.value.toUpperCase();
    setPan(value);

    setErrors((prev) => ({
      ...prev,
      pan: validatePan(value),
    }));
  }}
/>

{errors.pan && <p className="error-text">{errors.pan}</p>}
<input type="file" onChange={(e) => setPanFile(e.target.files[0])} />

<input
  type="text"
  placeholder="Driving License"
  className={errors.dl ? "input-error" : ""}
  onChange={(e) => {
    const v = e.target.value;
    setDlNumber(v);
    setErrors((prev) => ({ ...prev, dl: validateDL(v) }));
  }}
/>
{errors.dl && <p className="error-text">{errors.dl}</p>}
<input type="file" onChange={(e) => setDlFile(e.target.files[0])} />

<input
  type="date"
  className={errors.dlExpiry ? "input-error" : ""}
  onChange={(e) => {
    const v = e.target.value;
    setDlExpiry(v);
    setErrors((prev) => ({
      ...prev,
      dlExpiry: validateDLExpiry(v),
    }));
  }}
/>
{errors.dlExpiry && (
  <p className="error-text">{errors.dlExpiry}</p>
)}
<input
  type="text"
  placeholder="Bank Account Number"
  className={errors.bank ? "input-error" : ""}
  onChange={(e) => {
    const value = e.target.value;
    setBankAccount(value);

    setErrors((prev) => ({
      ...prev,
      bank: validateBank(value),
    }));
  }}
/>

{errors.bank && <p className="error-text">{errors.bank}</p>}
<input
  type="text"
  placeholder="IFSC Code"
  className={errors.ifsc ? "input-error" : ""}
  onChange={(e) => {
    const value = e.target.value.toUpperCase();
    setIfsc(value);

    setErrors((prev) => ({
      ...prev,
      ifsc: validateIFSC(value),
    }));
  }}
/>

{errors.ifsc && <p className="error-text">{errors.ifsc}</p>}

<input
  type="text"
  placeholder="Account Holder Name"
  className={errors.accountHolder ? "input-error" : ""}
  onChange={(e) => {
    const v = e.target.value;
    setAccountHolder(v);

    setErrors((prev) => ({
      ...prev,
      accountHolder: validateAccountHolder(v),
    }));
  }}
/>

{errors.accountHolder && (
  <p className="error-text">{errors.accountHolder}</p>
)}
<input
  type="text"
  placeholder="UPI ID"
  className={errors.upi ? "input-error" : ""}
  onChange={(e) => {
    const value = e.target.value;
    setUpiId(value);

    setErrors((prev) => ({
      ...prev,
      upi: validateUPI(value),
    }));
  }}
/>

{errors.upi && <p className="error-text">{errors.upi}</p>}

      <video ref={videoRef} autoPlay />

      <div className="btn-group">
        <button onClick={startCamera}>Start Camera</button>
        <button onClick={detectFace}>Detect</button>
        <button onClick={capture}>Capture</button>
      </div>

      {image && <img src={image} alt="preview" className="preview" />}

      {message && <p className="message">{message}</p>}

      <button className="submit" onClick={handleSubmit}>
        Register
      </button>

      <p>
        Already have account? <a href="/login">Login here</a>
      </p>
    </div>
  </div>
);
}

export default FaceRegister;  