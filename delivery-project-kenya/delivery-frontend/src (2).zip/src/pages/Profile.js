import React, { useState, useEffect } from 'react';
import { HiOutlineStar } from 'react-icons/hi';
import LoadingSkeleton from '../components/LoadingSkeleton';
import '../styles/Profile.css';

function Profile() {
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [profile, setProfile] = useState({});
  const [stats, setStats] = useState({ totalDeliveries: 0, rating: 4.8 });
  const [orders, setOrders] = useState([]);
  const [loggedUser, setLoggedUser] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("loggedInUser"));
    if (!user) {
      window.location.href = "/login";
      return;
    }
    setLoggedUser(user);
    fetchProfileData(user.id);
  }, []);

  const fetchProfileData = async (userId) => {
    try {
      // Fetch profile
      const profileRes = await fetch(`http://localhost:5000/profile/${userId}`);
      const profileData = await profileRes.json();
      if (profileData.success) {
        setProfile(profileData.user);
      }

      // Fetch orders for stats
      const ordersRes = await fetch(`http://localhost:5000/orders/${userId}`);
      const ordersData = await ordersRes.json();
      if (ordersData.success) {
        const deliveredCount = ordersData.orders.filter(o => o.status === 'delivered').length;
        setOrders(ordersData.orders);
        setStats({ totalDeliveries: deliveredCount, rating: 4.8 }); // Rating dummy, avg later
      }
    } catch (err) {
      console.error('Profile fetch error:', err);
      setError('Failed to load profile data');
      // Fallback
      setProfile({
        id: "DP-2847",
        name: loggedUser?.name || "Rahul Sharma",
        email: loggedUser?.email || "rahul@delivery.com",
        mobile: loggedUser?.mobile || "+91 98765 43210",
        // ... other static
      });
      setStats({ totalDeliveries: 3247, rating: 4.8 });
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field, value) => {
    setProfile((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = async () => {
    // TODO: POST to /update-profile/:id
    console.log('Saving profile:', profile);
    setEditing(false);
    alert('Profile updated! (API integration pending)');
  };

  const handleCancel = () => {
    setEditing(false);
  };

  if (loading) {
    return (
      <div>
        <div className="page-header">
          <h1>Profile</h1>
          <p>Loading your account...</p>
        </div>
        <LoadingSkeleton type="grid" count={2} />
      </div>
    );
  }

  const initials = profile.name
    ?.split(' ')
    .map((n) => n[0])
    .join('') || 'RS';

  const joinedYear = profile.created_at ? new Date(profile.created_at).getFullYear() : 2024;

  return (
    <div>
      <div className="page-header">
        <h1>Profile</h1>
        <p>Account details for {profile.name}</p>
        {error && <p style={{color: 'orange'}}>{error}</p>}
      </div>

      <div className="profile-layout">
        {/* Dynamic Profile Card */}
        <div className="profile-card">
          <div className="profile-avatar-large" style={{background: `linear-gradient(135deg, ${loggedUser?.descriptor ? '#00d4ff' : '#6c5ce7'}, #a55eea)`}}>
            {initials}
          </div>
          <h2>{profile.name || loggedUser?.name}</h2>
          <p className="profile-id">ID: {profile.id || loggedUser?.id}</p>

          <div className="profile-rating">
            <div className="stars">
              {[1, 2, 3, 4, 5].map((star) => (
                <HiOutlineStar
                  key={star}
                  style={{
                    fill: star <= Math.floor(stats.rating) ? '#FDCB6E' : 'none',
                    color: '#FDCB6E',
                  }}
                />
              ))}
            </div>
            <span>{stats.rating.toFixed(1)}</span>
          </div>

          <div className="profile-stats-row">
            <div className="profile-stat">
              <h4>{stats.totalDeliveries.toLocaleString()}</h4>
              <p>Delivered Orders</p>
            </div>
            <div className="profile-stat">
              <h4>Since {joinedYear}</h4>
              <p>Member Since</p>
            </div>
          </div>
        </div>

        {/* Editable Profile Form */}
        <div className="profile-form-section">
          <div className="profile-form-header">
            <h3>Personal Information</h3>
            <button
              className="edit-toggle-btn"
              onClick={() => setEditing(!editing)}
            >
              {editing ? 'Cancel' : '✏️ Edit'}
            </button>
          </div>

          <div className="profile-form">
            <div className="form-grid">
              <div className="form-group">
                <label>Full Name</label>
                <input
                  type="text"
                  value={profile.name || ''}
                  disabled={!editing}
                  onChange={(e) => handleChange('name', e.target.value)}
                />
              </div>
              <div className="form-group">
                <label>Email</label>
                <input
                  type="email"
                  value={profile.email || ''}
                  disabled={!editing}
                  onChange={(e) => handleChange('email', e.target.value)}
                />
              </div>
              <div className="form-group">
                <label>Mobile</label>
                <input
                  type="tel"
                  value={profile.mobile || profile.phone || ''}
                  disabled={!editing}
                  onChange={(e) => handleChange('mobile', e.target.value)}
                />
              </div>
              <div className="form-group">
                <label>Descriptor</label>
                <input
                  type="text"
                  value={profile.descriptor ? 'Face Verified' : 'Pending'}
                  disabled
                />
              </div>
              <div className="form-group full-width">
                <label>City</label>
                <input
                  type="text"
                  value={profile.city || ''}
                  disabled={!editing}
                  onChange={(e) => handleChange('city', e.target.value)}
                />
              </div>
            </div>
          </div>

          {editing && (
            <div className="profile-form-actions">
              <button className="btn btn-outline" onClick={handleCancel}>
                Cancel
              </button>
              <button className="btn btn-primary" onClick={handleSave}>
                💾 Save Changes
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default Profile;
