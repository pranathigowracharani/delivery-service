function Navbar() {
  return (
    <div className="card" style={{display:"flex", justifyContent:"space-between"}}>
      <h3>PRIME BASKET</h3>
      <div>
        <span style={{marginRight:20}}>Dashboard</span>
        <span style={{marginRight:20}}>Shipping</span>
        <span>Tracking</span>
      </div>
    </div>
  );
}

export default Navbar;