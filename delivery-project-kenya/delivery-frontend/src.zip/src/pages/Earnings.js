import React, { useState, useEffect } from 'react';
import LoadingSkeleton from '../components/LoadingSkeleton';
import { earningsData } from '../data/data';
import '../styles/Earnings.css';

function Earnings() {
  const [loading, setLoading] = useState(true);
  const [chartView, setChartView] = useState('weekly');

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 900);
    return () => clearTimeout(timer);
  }, []);

  const chartData =
    chartView === 'weekly'
      ? earningsData.weeklyBreakdown
      : earningsData.monthlyBreakdown;

  const maxAmount = Math.max(...chartData.map((d) => d.amount));

  if (loading) {
    return (
      <div>
        <div className="page-header">
          <h1>Earnings</h1>
          <p>Track your income and payouts</p>
        </div>
        <LoadingSkeleton type="grid" count={4} />
        <div style={{ marginTop: 24 }}>
          <LoadingSkeleton type="rows" count={4} />
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="page-header">
        <h1>Earnings</h1>
        <p>Track your income and payouts</p>
      </div>

      {/* Summary Cards */}
      <div className="earnings-summary">
        <div className="earnings-card highlight">
          <div className="earnings-card-label">Today's Earnings</div>
          <div className="earnings-card-value">₹{earningsData.today.toLocaleString()}</div>
          <div className="earnings-card-trend">↑ 18% vs yesterday</div>
        </div>
        <div className="earnings-card">
          <div className="earnings-card-label">This Week</div>
          <div className="earnings-card-value">₹{earningsData.thisWeek.toLocaleString()}</div>
          <div className="earnings-card-trend">↑ 12% vs last week</div>
        </div>
        <div className="earnings-card">
          <div className="earnings-card-label">This Month</div>
          <div className="earnings-card-value">₹{earningsData.thisMonth.toLocaleString()}</div>
          <div className="earnings-card-trend">↑ 11% vs last month</div>
        </div>
        <div className="earnings-card">
          <div className="earnings-card-label">Last Month</div>
          <div className="earnings-card-value">₹{earningsData.lastMonth.toLocaleString()}</div>
          <div className="earnings-card-trend negative">↓ 5% vs prior</div>
        </div>
      </div>

      {/* Chart + Payouts Grid */}
      <div className="earnings-grid">
        {/* Bar Chart */}
        <div className="chart-section">
          <div className="chart-header">
            <h3>📊 Earnings Overview</h3>
            <div className="chart-tabs">
              <button
                className={`chart-tab ${chartView === 'weekly' ? 'active' : ''}`}
                onClick={() => setChartView('weekly')}
              >
                Weekly
              </button>
              <button
                className={`chart-tab ${chartView === 'monthly' ? 'active' : ''}`}
                onClick={() => setChartView('monthly')}
              >
                Monthly
              </button>
            </div>
          </div>
          <div className="chart-body">
            <div className="bar-chart">
              {chartData.map((item, idx) => {
                const heightPercent = (item.amount / maxAmount) * 100;
                return (
                  <div key={idx} className="bar-group">
                    <div className="bar-wrapper">
                      <div
                        className="bar"
                        style={{ height: `${heightPercent}%` }}
                      >
                        <span className="bar-tooltip">
                          ₹{item.amount.toLocaleString()}
                        </span>
                      </div>
                    </div>
                    <span className="bar-label">
                      {item.day || item.month}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Recent Payouts */}
        <div className="payouts-section">
          <div className="payouts-header">
            <h3>💰 Recent Payouts</h3>
          </div>
          {earningsData.recentPayouts.map((payout) => (
            <div key={payout.id} className="payout-item">
              <div className="payout-info">
                <h4>{payout.id}</h4>
                <p>{payout.date}</p>
              </div>
              <span className="payout-amount">{payout.amount}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Earnings;
