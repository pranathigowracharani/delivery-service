import Sidebar from "./components/Sidebar";

function Layout({ children }) {
  return (
    <div className="dashboard-container">
      <Sidebar isOpen={true} />
      <div className="main-content">
        {children}
      </div>
    </div>
  );
}

export default Layout;