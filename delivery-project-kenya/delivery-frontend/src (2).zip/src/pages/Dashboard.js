import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  HiOutlineCube,
  HiOutlineCurrencyRupee,
  HiOutlineClock,
  HiOutlineCheckCircle,
} from 'react-icons/hi';
import StatusBadge from '../components/StatusBadge';
import LoadingSkeleton from '../components/LoadingSkeleton';
import '../styles/Dashboard.css';
import Sidebar from "../components/Sidebar";

function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [orders, setOrders] = useState([]);
  const [earnings, setEarnings] = useState({});
  const [user, setUser] = useState(null);

  useEffect(() => {
    const loggedUser = JSON.parse(localStorage.getItem("loggedInUser"));

    if (!loggedUser) {
      window.location.href = "/login";
      return;
    }

    setUser(loggedUser);

    const fetchData = async () => {
      try {
        // Fetch Orders
        const ordersRes = await fetch(`http://localhost:5000/orders/${loggedUser.id}`);
        const ordersData = await ordersRes.json();
        setOrders(ordersData.orders || []);

        // Fetch Earnings
        const earningsRes = await fetch(`http://localhost:5000/earnings/${loggedUser.id}`);
        const earningsData = await earningsRes.json();
        setEarnings(earningsData);
      } catch (error) {
        console.error('Fetch error:', error);
        setOrders([]);
        setEarnings({today: 0, thisWeek: 0, thisMonth: 0});
      } finally {
        setLoading(false);
      }
    };

    fetchData();

    const interval = setInterval(fetchData, 30000); // Poll every 30 seconds for dynamic updates

    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <div>
        <div className="page-header">
          <h1>Dashboard</h1>
          <p>Loading...</p>
        </div>
        <LoadingSkeleton type="grid" count={4} />
      </div>
    );
  }

  // 🔥 Dynamic Calculations
  const totalOrders = orders.length;
  const pendingOrders = orders.filter(o => o.status === "Pending").length;
  const completedOrders = orders.filter(o => o.status === "Delivered").length;

  return (
    <div className="dashboard-container">

      <Sidebar isOpen={true} />

      <div className="main-content">

        <div className="page-header">
          <h1>Dashboard</h1>
          <h3>Welcome, {user?.name}</h3>
          <p>Overview of your delivery performance</p>
        </div>

        {/* 🔥 Dynamic Cards */}
        <div className="dashboard-cards">

          <div className="summary-card purple">
            <HiOutlineCube />
            <h3>{totalOrders}</h3>
            <p>Total Orders</p>
          </div>

          <div className="summary-card green">
            <HiOutlineCurrencyRupee />
            <h3>₹{earnings.today || 0}</h3>
            <p>Earnings Today</p>
          </div>

          <div className="summary-card yellow">
            <HiOutlineClock />
            <h3>{pendingOrders}</h3>
            <p>Pending Orders</p>
          </div>

          <div className="summary-card blue">
            <HiOutlineCheckCircle />
            <h3>{completedOrders}</h3>
            <p>Completed Orders</p>
          </div>

        </div>

        {/* 🔥 GRID */}
        <div className="dashboard-grid">

          {/* Map */}
          <div className="map-section">
            <div className="map-header">
              <h3>📍 Live Delivery Map</h3>
              <span>{pendingOrders} active deliveries</span>
            </div>

            <div className="map-placeholder">
              <p style={{ textAlign: "center" }}>
                🚀 Map Integration Coming (Google Maps)
              </p>
            </div>
          </div>

          {/* 🔥 Recent Orders (DYNAMIC) */}
          <div className="recent-orders">
            <div className="recent-orders-header">
              <h3>Recent Orders</h3>
              <Link to="/active-orders">View All →</Link>
            </div>

            {orders.slice(0, 5).map((order) => (
              <div key={order.id} className="recent-order-item">

                <div className="recent-order-info">
                  <div className="recent-order-avatar">
                    {order.customer_name?.charAt(0)}
                  </div>

                  <div>
                    <h4>{order.customer_name}</h4>
                    <p>{order.order_id}</p>
                  </div>
                </div>

                <div className="recent-order-meta">
                  <span>{order.amount}</span>
                  <StatusBadge status={order.status} />
                </div>

              </div>
            ))}

          </div>

        </div>

      </div>
    </div>
  );
}

export default Dashboard;