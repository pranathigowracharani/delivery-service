import React, { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { HiOutlineSearch, HiOutlineBell, HiOutlineMenu } from 'react-icons/hi';
import { notifications as notificationsData } from '../data/data';
import '../styles/TopNavbar.css';
import '../styles/Notifications.css';

function TopNavbar({ onMenuToggle }) {
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifs, setNotifs] = useState(notificationsData);
  const dropdownRef = useRef(null);

  const unreadCount = notifs.filter((n) => !n.read).length;

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  const toggleNotifications = () => {
    setShowNotifications((prev) => !prev);
  };

  const markAllRead = () => {
    setNotifs((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const handleNotificationClick = (notif) => {
    setNotifs((prev) =>
      prev.map((n) => (n.id === notif.id ? { ...n, read: true } : n))
    );
    if (notif.actionLink) {
      setShowNotifications(false);
    }
  };

  // Close on outside click
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setShowNotifications(false);
      }
    };
    if (showNotifications) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showNotifications]);

  return (
    <header className="topbar">
      <div className="topbar-left">
        <button className="mobile-menu-btn" onClick={onMenuToggle}>
          <HiOutlineMenu />
        </button>
        <div className="topbar-greeting">
          <h2>{getGreeting()}, Rahul! 👋</h2>
          <p>Here's what's happening with your deliveries today.</p>
        </div>
      </div>

      <div className="topbar-right">
        <div className="topbar-search">
          <HiOutlineSearch className="topbar-search-icon" />
          <input type="text" placeholder="Search orders..." />
        </div>

        {/* Notification Bell + Dropdown */}
        <div className="notification-wrapper" ref={dropdownRef}>
          <button
            className="topbar-icon-btn"
            id="notifications-btn"
            onClick={toggleNotifications}
          >
            <HiOutlineBell />
            {unreadCount > 0 && (
              <span className="topbar-notification-dot"></span>
            )}
          </button>

          {showNotifications && (
            <div className="notification-dropdown">
              <div className="notification-dropdown-header">
                <h3>
                  Notifications{' '}
                  {unreadCount > 0 && (
                    <span className="notification-unread-count">
                      {unreadCount} new
                    </span>
                  )}
                </h3>
                {unreadCount > 0 && (
                  <button className="mark-read-btn" onClick={markAllRead}>
                    Mark all read
                  </button>
                )}
              </div>

              <div className="notification-list">
                {notifs.map((notif) => (
                  <div
                    key={notif.id}
                    className={`notification-item ${!notif.read ? 'unread' : ''}`}
                    onClick={() => handleNotificationClick(notif)}
                  >
                    <div className={`notification-icon-wrapper ${notif.type}`}>
                      {notif.icon}
                    </div>
                    <div className="notification-content">
                      <div className="notification-title">{notif.title}</div>
                      <div className="notification-message">{notif.message}</div>
                      <div className="notification-meta">
                        <span className="notification-time">{notif.time}</span>
                        {notif.actionText && notif.actionLink && (
                          <Link
                            to={notif.actionLink}
                            className="notification-action-link"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleNotificationClick(notif);
                            }}
                          >
                            {notif.actionText} →
                          </Link>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="notification-dropdown-footer">
                <Link
                  to="/coupons"
                  onClick={() => setShowNotifications(false)}
                >
                  View All Rewards & Coupons →
                </Link>
              </div>
            </div>
          )}
        </div>

        <Link to="/profile" className="topbar-avatar" id="user-avatar">
          RS
        </Link>
      </div>
    </header>
  );
}

export default TopNavbar;
