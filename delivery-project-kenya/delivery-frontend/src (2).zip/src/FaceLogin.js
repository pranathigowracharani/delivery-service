import { useRef, useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import * as faceapi from "face-api.js";
import "./Login.css";

function FaceLogin() {
  const videoRef = useRef();
  const [image, setImage] = useState("");
  const [modelLoaded, setModelLoaded] = useState(false);
  const [faceDetected, setFaceDetected] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState("");
  const navigate = useNavigate();
  const [identifier, setIdentifier] = useState(""); // email OR mobile
const [password, setPassword] = useState("");

  // ✅ Load Models
  useEffect(() => {
    const loadModels = async () => {
      await faceapi.nets.tinyFaceDetector.loadFromUri("/models");
      await faceapi.nets.faceLandmark68Net.loadFromUri("/models");
      await faceapi.nets.faceRecognitionNet.loadFromUri("/models");
      console.log("✅ Models Loaded");
      setModelLoaded(true);
    };
    loadModels();
  }, []);

  // ✅ Start Camera
  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      videoRef.current.srcObject = stream;
    } catch (err) {
      setMessage("Camera access denied");
    }
  };

  // ✅ Detect Face
  const detectFace = async () => {
    if (!modelLoaded) {
      setMessage("⚙️ Loading AI model...");
      return;
    }

    const result = await faceapi.detectSingleFace(
      videoRef.current,
      new faceapi.TinyFaceDetectorOptions()
    );

    setFaceDetected(!!result);
  };

  // ✅ Capture Image
  const capture = () => {
    if (!faceDetected) {
      setMessage("Detect face first");
      return;
    }

    if (!modelLoaded) {
      setMessage("⚙️ Wait, model loading...");
      return;
    }

    const canvas = document.createElement("canvas");
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;

    const ctx = canvas.getContext("2d");
    ctx.drawImage(videoRef.current, 0, 0);

    const data = canvas.toDataURL("image/png");
    setImage(data);
    setFaceDetected(true);
    setMessage("Face captured ✓ Ready to login");
  };

  // ✅ LOGIN FUNCTION (FINAL FIXED)
  const handleLogin = async () => {
    setIsLoading(true);
    setMessage("");

    try {
      // ✅ FIRST CHECKS
      if (!image) {
        setMessage("Please capture image first");
        setIsLoading(false);
        return;
      }

      if (!modelLoaded) {
        setMessage("⚙️ Model still loading...");
        setIsLoading(false);
        return;
      }

      // ✅ Detect face from captured image
      const img = await faceapi.fetchImage(image);

      const result = await faceapi
        .detectSingleFace(img, new faceapi.TinyFaceDetectorOptions())
        .withFaceLandmarks()
        .withFaceDescriptor();

      if (!result) {
        setMessage("No face detected in captured image");
        setIsLoading(false);
        return;
      }

      const loginDescriptor = result.descriptor;

      // ✅ Fetch users from backend
      const res = await fetch("http://localhost:5000/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ identifier, password }),
    });

    const data = await res.json();

    if (!data.success) {
      setMessage("❌ Invalid email/mobile or password");
      setIsLoading(false);
      return;
    }

    const user = data.user;

    // STEP 2: Face match ONLY with that user
    const dbDescriptor = new Float32Array(
      JSON.parse(user.descriptor)
    );

    const distance = faceapi.euclideanDistance(
      loginDescriptor,
      dbDescriptor
    );

    if (distance < 0.45) {
     localStorage.setItem("loggedInUser", JSON.stringify(user));
      alert("✅ Login Successful!");
      navigate("/dashboard");
    } else {
      setMessage("❌ Face does not match");
    }
    } catch (err) {
      console.error(err);
      setMessage("Login failed: " + err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container">
      <div className="login-container">
        <h2>🔐 Face Login</h2>
        <p>Secure biometric authentication</p>
        <input
          type="text"
          placeholder="Email or Mobile"
          onChange={(e) => setIdentifier(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          onChange={(e) => setPassword(e.target.value)}
        />
        <video ref={videoRef} autoPlay muted className="video" />

        {/* Model Status */}
        {!modelLoaded && <p>⚙️ Initializing AI... Please wait</p>}

        {/* Face Status */}
        <div
          className={`face-status ${
            faceDetected ? "status-detected" : "status-searching"
          }`}
        >
          {faceDetected ? "✅ Face Detected" : "👀 Looking for face..."}
        </div>

        {/* Buttons */}
        <div className="btn-group-login">
          <button className="btn-login" onClick={startCamera}>
            Start Camera
          </button>
          <button className="btn-login" onClick={detectFace}>
            Detect Face
          </button>
          <button
            className="btn-login"
            onClick={capture}
            disabled={!faceDetected}
          >
            Capture
          </button>
        </div>

        {/* Preview */}
        {image && (
          <img src={image} className="preview-login" alt="captured" />
        )}

        {/* Message */}
        {message && (
          <p
            className={`message ${
              message.includes("✓") ? "success" : "error"
            }`}
          >
            {message}
          </p>
        )}

        {/* Login Button */}
        <button
          className="login-btn"
          onClick={handleLogin}
          disabled={!image || isLoading}
        >
          {isLoading ? "🔄 Authenticating..." : "🚀 Login with Face"}
        </button>

        <p style={{ marginTop: "20px", fontSize: "14px", color: "#666" }}>
          Threshold: 0.7 distance
        </p>
        <p>
  New user? <a href="/">Register here</a>
</p>
      </div>
    </div>
  );
}

export default FaceLogin;