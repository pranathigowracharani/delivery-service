import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import FaceRegister from "./FaceRegister";
import Home from "./Home";
import FaceLogin from "./FaceLogin";
import Dashboard from "./pages/Dashboard";
import Layout from "./Layout";
import ActiveOrders from "./pages/ActiveOrders";
import OrderHistory from "./pages/OrderHistory";
import Earnings from "./pages/Earnings";
import Coupons from "./pages/Coupons";
import Profile from "./pages/Profile";

function App() {
  return (
    <Router>
   
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/register" element={<FaceRegister />} />
        <Route path="/login" element={<FaceLogin />} />
        <Route path="/dashboard" element={<Layout><Dashboard /></Layout>} />
<Route path="/active-orders" element={<Layout><ActiveOrders /></Layout>} />
<Route path="/order-history" element={<Layout><OrderHistory /></Layout>} />
<Route path="/earnings" element={<Layout><Earnings /></Layout>} />
<Route path="/coupons" element={<Layout><Coupons /></Layout>} />
<Route path="/profile" element={<Layout><Profile /></Layout>} />
        {/* <Route path="*" element={<FaceRegister />} /> */}
      </Routes>
    </Router>
  );
}

export default App;
