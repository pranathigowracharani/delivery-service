import React, { useState, useEffect } from 'react';
import { HiOutlineStar } from 'react-icons/hi';
import LoadingSkeleton from '../components/LoadingSkeleton';
import { deliveryPartner } from '../data/data';
import '../styles/Profile.css';

function Profile() {
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [profile, setProfile] = useState(deliveryPartner);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 700);
    return () => clearTimeout(timer);
  }, []);

  const handleChange = (field, value) => {
    setProfile((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    setEditing(false);
    // In production this would call an API
  };

  const handleCancel = () => {
    setProfile(deliveryPartner);
    setEditing(false);
  };

  if (loading) {
    return (
      <div>
        <div className="page-header">
          <h1>Profile</h1>
          <p>Your account details</p>
        </div>
        <LoadingSkeleton type="grid" count={2} />
      </div>
    );
  }

  const initials = profile.name
    .split(' ')
    .map((n) => n[0])
    .join('');

  return (
    <div>
      <div className="page-header">
        <h1>Profile</h1>
        <p>Your account details</p>
      </div>

      <div className="profile-layout">
        {/* Profile Card */}
        <div className="profile-card">
          <div className="profile-avatar-large">{initials}</div>
          <h2>{profile.name}</h2>
          <p className="profile-id">ID: {profile.id}</p>

          <div className="profile-rating">
            <div className="stars">
              {[1, 2, 3, 4, 5].map((star) => (
                <HiOutlineStar
                  key={star}
                  style={{
                    fill: star <= Math.floor(profile.rating) ? '#FDCB6E' : 'none',
                    color: '#FDCB6E',
                  }}
                />
              ))}
            </div>
            <span>{profile.rating}</span>
          </div>

          <div className="profile-stats-row">
            <div className="profile-stat">
              <h4>{profile.totalDeliveries.toLocaleString()}</h4>
              <p>Total Deliveries</p>
            </div>
            <div className="profile-stat">
              <h4>Since {new Date(profile.joinedDate).getFullYear()}</h4>
              <p>Member Since</p>
            </div>
          </div>
        </div>

        {/* Profile Form */}
        <div className="profile-form-section">
          <div className="profile-form-header">
            <h3>Personal Information</h3>
            <button
              className="edit-toggle-btn"
              onClick={() => setEditing(!editing)}
            >
              {editing ? 'Cancel Edit' : '✏️ Edit Profile'}
            </button>
          </div>

          <div className="profile-form">
            <div className="form-grid">
              <div className="form-group">
                <label>Full Name</label>
                <input
                  type="text"
                  value={profile.name}
                  disabled={!editing}
                  onChange={(e) => handleChange('name', e.target.value)}
                />
              </div>
              <div className="form-group">
                <label>Email Address</label>
                <input
                  type="email"
                  value={profile.email}
                  disabled={!editing}
                  onChange={(e) => handleChange('email', e.target.value)}
                />
              </div>
              <div className="form-group">
                <label>Phone Number</label>
                <input
                  type="tel"
                  value={profile.phone}
                  disabled={!editing}
                  onChange={(e) => handleChange('phone', e.target.value)}
                />
              </div>
              <div className="form-group">
                <label>Vehicle</label>
                <input
                  type="text"
                  value={profile.vehicle}
                  disabled={!editing}
                  onChange={(e) => handleChange('vehicle', e.target.value)}
                />
              </div>
              <div className="form-group">
                <label>Vehicle Number</label>
                <input
                  type="text"
                  value={profile.vehicleNumber}
                  disabled={!editing}
                  onChange={(e) => handleChange('vehicleNumber', e.target.value)}
                />
              </div>
              <div className="form-group">
                <label>Bank Account</label>
                <input type="text" value={profile.bankAccount} disabled />
              </div>
              <div className="form-group full-width">
                <label>Address</label>
                <textarea
                  value={profile.address}
                  disabled={!editing}
                  onChange={(e) => handleChange('address', e.target.value)}
                  rows="3"
                />
              </div>
            </div>
          </div>

          {editing && (
            <div className="profile-form-actions">
              <button className="btn btn-outline" onClick={handleCancel}>
                Cancel
              </button>
              <button className="btn btn-primary" onClick={handleSave}>
                Save Changes
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default Profile;
