function TrackingPanel() {
  return (
    <div className="card" style={{width:"950px"}}>
      <h3>Live Tracking</h3>
      <p><b>Tracking ID:</b> #TS4562</p>

      <ul>
        <li>Checking</li>
        <li>In Transit</li>
        <li>Out for Delivery</li>
      </ul>

      <button>New Shipping</button>
    </div>
  );
}

export default TrackingPanel;